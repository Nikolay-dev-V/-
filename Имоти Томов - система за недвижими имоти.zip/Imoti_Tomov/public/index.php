<?php
declare(strict_types=1);
require __DIR__.'/../app/Core.php';
require __DIR__.'/../app/Actions.php';
require __DIR__.'/../app/Pages.php';
require __DIR__.'/../app/Public.php';

function explain_error(Throwable $error): string {
    if ($error instanceof PDOException) {
        error_log('[Имоти Томов] '.$error->getMessage());
        if($error->getCode()==='23000')return 'Записът нарушава уникално ограничение или вече е свързан с друг запис.';
        return 'Възникна грешка при работа с базата данни. Проверете настройките и въведените данни.';
    }
    if ($error instanceof DomainException || ($error instanceof RuntimeException && $error->getCode()>=400 && $error->getCode()<500)) return $error->getMessage();
    error_log('[Имоти Томов] '.$error);
    return 'Неочаквана грешка. Проверете системния журнал.';
}

$action=(string)($_GET['action']??'');
if($action!==''){
    try{if(in_array($action,['register','favorite_toggle'],true))public_action($action);else do_action($action);}catch(Throwable $err){
        $message=explain_error($err);
        $code=(int)$err->getCode();
        if(in_array($code,[403,419],true)){http_response_code($code);echo '<meta charset="utf-8"><h1>Заявката е отказана</h1><p>'.esc($message).'</p><a href="'.esc(route('catalog')).'">Към началото</a>';exit;}
        $target=match($action){
            'login'=>'login','register'=>'register','favorite_toggle'=>'catalog',
            'property_save'=>'property_form','property_photo','photo_delete','property_status','property_delete'=>'properties',
            'client_save'=>'client_form','client_delete'=>'clients','requirement_save','requirement_delete','interest_save'=>'clients',
            'viewing_save','viewing_status'=>'viewings',
            'deal_save','deal_status'=>'deals',
            'employee_save','employee_status'=>'employees',
            'expense_save','expense_delete'=>'finance','document_upload','document_delete'=>'documents',
            default=>'dashboard',
        };
        flash($message,'error');
        $params=[];
        if($target==='property_form'&&isset($_POST['id'])&&(int)$_POST['id']>0)$params=['id'=>(int)$_POST['id']];
        if($target==='client_form'&&isset($_POST['id'])&&(int)$_POST['id']>0)$params=['id'=>(int)$_POST['id']];
        go($target,$params);
    }
}
$page=(string)($_GET['page']??(current_user() && is_staff()?'dashboard':'catalog'));
try {
    if($page==='export'){csv_export((string)($_GET['kind']??'properties'));}
    if($page==='viewing_print'){page_viewing_print();}
    if($page==='download'){send_file('document',(int)($_GET['id']??0));}
    if($page==='photo'){send_file('photo',(int)($_GET['id']??0));}
    if(in_array($page,['login','register'],true) && current_user())go(is_staff()?'dashboard':'favorites');
    $publicPages=['catalog','public_property','login','register'];
    if($page==='favorites')only_roles('client');
    elseif(!in_array($page,$publicPages,true))only_roles('admin','broker');
    $titles=['catalog'=>'Обяви','public_property'=>'Предложение','register'=>'Регистрация','favorites'=>'Любими имоти','login'=>'Вход','dashboard'=>'Табло','properties'=>'Имоти','property'=>'Детайли за имот','property_form'=>'Имот','clients'=>'Клиенти','client'=>'Клиент','client_form'=>'Клиент','requirement_form'=>'Критерии','viewings'=>'Огледи','deals'=>'Сделки','matching'=>'Matching','finance'=>'Финанси','reports'=>'Справки','employees'=>'Служители','documents'=>'Документи'];
    if(!isset($titles[$page]))fail(404,'Страницата не е намерена.');
    $active=match($page){'property','property_form'=>'properties','client','client_form','requirement_form'=>'clients',default=>$page};
    $isPublic=in_array($page,['catalog','public_property','register','favorites'],true);
    if($isPublic)public_layout_start($titles[$page]);else layout_start($titles[$page],$active);
    switch($page){
        case 'catalog':page_catalog();break;
        case 'public_property':page_public_property();break;
        case 'register':page_register();break;
        case 'favorites':page_favorites();break;
        case 'login':page_login();break;
        case 'dashboard':page_dashboard();break;
        case 'properties':page_properties();break;
        case 'property_form':page_property_form();break;
        case 'property':page_property();break;
        case 'clients':page_clients();break;
        case 'client_form':page_client_form();break;
        case 'client':page_client();break;
        case 'requirement_form':page_requirement_form();break;
        case 'viewings':page_viewings();break;
        case 'deals':page_deals();break;
        case 'matching':page_matching();break;
        case 'finance':page_finance();break;
        case 'reports':page_reports();break;
        case 'employees':page_employees();break;
        case 'documents':page_documents();break;
    }
    if($isPublic)public_layout_end();else layout_end();
}catch(Throwable $err){
    $code=(int)$err->getCode();http_response_code($code>=400&&$code<600?$code:500);
    echo '<!doctype html><html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="'.esc(base_url()).'/assets/css/style.css"><title>Грешка</title></head><body class="error-body"><div class="error-card"><h1>Възникна проблем</h1><p>'.esc(explain_error($err)).'</p><a class="button primary" href="'.esc(route()).'">Към началото</a></div></body></html>';
}
