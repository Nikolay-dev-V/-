'use strict';
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-confirm]').forEach(button => {
    button.addEventListener('click', event => {
      if (!window.confirm(button.getAttribute('data-confirm') || 'Потвърждавате ли?')) event.preventDefault();
    });
  });
  document.querySelectorAll('.notice-close').forEach(button => button.addEventListener('click', () => button.closest('.notice')?.remove()));
  const toggle = document.getElementById('menu-toggle');
  toggle?.addEventListener('click', () => document.getElementById('sidebar')?.classList.toggle('open'));
  document.addEventListener('click', (event) => {
    if (window.innerWidth < 920 && !event.target.closest('#sidebar') && !event.target.closest('#menu-toggle')) document.getElementById('sidebar')?.classList.remove('open');
  });
});
