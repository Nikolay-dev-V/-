<?php
declare(strict_types=1);
require __DIR__.'/../app/Core.php';
$error='';$ok=false;
try {
    $admins=(int)value_of("SELECT COUNT(*) FROM users WHERE role='admin'");
    if($_SERVER['REQUEST_METHOD']==='POST' && $admins===0){
        assert_post();
        $name=Rules::required((string)($_POST['name']??''),'Име');
        $email=trim((string)($_POST['email']??''));$pass=(string)($_POST['password']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new DomainException('Въведете валиден имейл.');
        if(strlen($pass)<10)throw new DomainException('Паролата трябва да има поне 10 символа.');
        run_sql("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')",[$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);
        $ok=true;$admins=1;
    }
} catch(Throwable $e) {
    $error=$e instanceof PDOException?'Неуспешна връзка с базата. Импортирайте database/schema.sql и проверете app/config.php.':$e->getMessage();
    error_log('[Имоти Томов setup] '.$e);
    $admins=$admins??0;
}
?><!doctype html><html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Начална настройка | Имоти Томов</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="<?=esc(base_url())?>/assets/css/style.css"></head><body class="guest"><main class="login-main"><div class="login-card"><div class="login-logo"><span>⌂</span> Имоти Томов</div><p class="login-eyebrow">ПЪРВОНАЧАЛНА ИНСТАЛАЦИЯ</p><h1>Създаване на администратор</h1><?php if($error):?><div class="notice error"><?=esc($error)?></div><?php endif;?><?php if($admins>0):?><p class="lead"><?=$ok?'Администраторът беше създаден успешно.':'Системата вече има администратор. Инсталацията е заключена.'?></p><a class="button primary wide" href="<?=esc(route('login'))?>">Към входа →</a><?php else:?><?php form_open_setup();?><label class="field"><span>Име *</span><input name="name" required maxlength="150"></label><label class="field"><span>Имейл *</span><input name="email" type="email" required></label><label class="field"><span>Парола (10+ символа) *</span><input name="password" type="password" minlength="10" required></label><button class="button primary wide">Създай администратор</button></form><?php endif;?></div></main></body></html>
<?php function form_open_setup(): void {echo '<form method="post" class="login-form">'.csrf_field();} ?>
