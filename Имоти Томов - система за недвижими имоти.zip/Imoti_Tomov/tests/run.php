<?php
declare(strict_types=1);
require __DIR__.'/../app/Rules.php';
$passed=0;$failed=0;
function test(string $name,callable $fn):void{global $passed,$failed;try{$fn();echo "[PASS] $name\n";$passed++;}catch(Throwable $e){echo "[FAIL] $name: {$e->getMessage()}\n";$failed++;}}
function same(mixed $expected,mixed $actual):void{if($expected!==$actual)throw new Exception('Expected '.var_export($expected,true).' got '.var_export($actual,true));}
function throws(callable $fn):void{$ok=false;try{$fn();}catch(DomainException $e){$ok=true;}if(!$ok)throw new Exception('Expected DomainException');}

test('Комисионна 3% от 100000',fn()=>same(3000.0,Rules::commission(100000,3)));
test('Комисионна 2.5% от 840',fn()=>same(21.0,Rules::commission(840,2.5)));
test('Нулева комисионна',fn()=>same(0.0,Rules::commission(200,0)));
test('Отрицателен процент: отказ',fn()=>throws(fn()=>Rules::commission(100,-1)));
test('Процент над 100: отказ',fn()=>throws(fn()=>Rules::commission(100,101)));
test('Отрицателна сума: отказ',fn()=>throws(fn()=>Rules::commission(-20,3)));
test('Застъпващи се огледи',fn()=>same(true,Rules::intervalsOverlap('2026-11-12 11:00:00',60,'2026-11-12 11:30:00',60)));
test('Огледи с обща граница не се застъпват',fn()=>same(false,Rules::intervalsOverlap('2026-11-12 11:00:00',60,'2026-11-12 12:00:00',60)));
test('Огледи в различни дни',fn()=>same(false,Rules::intervalsOverlap('2026-11-12 11:00:00',60,'2026-11-13 11:00:00',60)));
test('Невалиден интервал: отказ',fn()=>throws(fn()=>Rules::intervalsOverlap('2026-11-12 11:00:00',0,'2026-11-12 11:30:00',60)));
test('Приключена продажба',fn()=>same('sold',Rules::completedStatus('sale')));
test('Приключен наем',fn()=>same('rented',Rules::completedStatus('rent')));
test('Невалиден вид сделка',fn()=>throws(fn()=>Rules::completedStatus('transfer')));
test('Администратор може да редактира чужд имот',fn()=>same(true,Rules::canChangeProperty(['id'=>5,'role'=>'admin'],['broker_id'=>8])));
test('Клиент няма право да редактира чужд имот',fn()=>same(false,Rules::canChangeProperty(['id'=>5,'role'=>'client'],['broker_id'=>8])));
test('Клиент няма право да редактира и собствен имот',fn()=>same(false,Rules::canChangeProperty(['id'=>5,'role'=>'client'],['broker_id'=>5])));
test('Брокер може да редактира свой имот',fn()=>same(true,Rules::canChangeProperty(['id'=>5,'role'=>'broker'],['broker_id'=>5])));
test('Брокер няма достъп до чужд имот',fn()=>same(false,Rules::canChangeProperty(['id'=>5,'role'=>'broker'],['broker_id'=>8])));
test('Валидна дата',fn()=>same(true,Rules::isValidDate('2026-11-12')));
test('Невалиден ден',fn()=>same(false,Rules::isValidDate('2026-02-30')));
test('Валиден datetime-local',fn()=>same(true,Rules::isValidDate('2026-11-12T14:30','Y-m-d\\TH:i')));
test('Невалиден datetime-local',fn()=>same(false,Rules::isValidDate('2026-11-12T25:30','Y-m-d\\TH:i')));
test('Положителна стойност',fn()=>same(80.5,Rules::nonNegative('80.50','Цена',true)));
test('Празно незадължително поле',fn()=>same(null,Rules::nonNegative('','Площ')));
test('Празно задължително поле',fn()=>throws(fn()=>Rules::nonNegative('','Цена',true)));
test('Отрицателна стойност',fn()=>throws(fn()=>Rules::nonNegative('-5','Цена')));
test('Задължително име',fn()=>same('Тест',Rules::required(' Тест ','Име')));
test('Празно задължително име',fn()=>throws(fn()=>Rules::required('   ','Име')));

echo "\nРезултат: $passed успешни, $failed неуспешни теста.\n";
exit($failed>0?1:0);
