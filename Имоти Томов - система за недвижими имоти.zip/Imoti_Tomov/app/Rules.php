<?php
declare(strict_types=1);

final class Rules {
    public static function money(float $amount): string { return number_format($amount, 2, ',', ' ') . ' €'; }
    public static function commission(float $amount, float $percent): float {
        if ($amount < 0 || $percent < 0 || $percent > 100) throw new DomainException('Невалидна комисионна.');
        return round($amount * $percent / 100, 2);
    }
    public static function intervalsOverlap(string $a, int $aMinutes, string $b, int $bMinutes): bool {
        $as = strtotime($a); $bs = strtotime($b);
        if ($as === false || $bs === false || $aMinutes <= 0 || $bMinutes <= 0) throw new DomainException('Невалиден интервал.');
        return $as < $bs + $bMinutes * 60 && $bs < $as + $aMinutes * 60;
    }
    public static function completedStatus(string $dealType): string {
        return match ($dealType) { 'sale' => 'sold', 'rent' => 'rented', default => throw new DomainException('Невалиден вид сделка.') };
    }
    public static function canChangeProperty(array $user, array $property): bool {
        return $user['role'] === 'admin' || ($user['role'] === 'broker' && (int)$user['id'] === (int)$property['broker_id']);
    }
    public static function isValidDate(string $date, string $format='Y-m-d'): bool {
        $parsed = DateTimeImmutable::createFromFormat('!'.$format, $date);
        return $parsed !== false && $parsed->format($format) === $date;
    }
    public static function nonNegative(?string $value, string $label, bool $required=false): ?float {
        if ($value === null || trim($value) === '') {
            if ($required) throw new DomainException('Полето „'.$label.'“ е задължително.');
            return null;
        }
        if (!is_numeric($value) || (float)$value < 0) throw new DomainException('Невалидна стойност за „'.$label.'“.');
        return (float)$value;
    }
    public static function required(string $value, string $label, int $max=190): string {
        $value=trim($value);
        if ($value==='' || (function_exists('mb_strlen')?mb_strlen($value,'UTF-8'):strlen($value))>$max) throw new DomainException('Попълнете коректно „'.$label.'“.');
        return $value;
    }
}
