<?php
declare(strict_types=1);

function require_active_broker(int $id): void {
    if (!one_row("SELECT id FROM users WHERE id=? AND active=1 AND role IN ('admin','broker')",[$id])) throw new DomainException('Изберете активен служител.');
}
function broker_for_property_form(): int {
    $broker=is_manager()?int_post('broker_id'):(int)must_login()['id'];
    require_active_broker($broker);return $broker;
}
function upload_secure(string $input, array $allowed, int $max=5242880): array {
    $file=$_FILES[$input]??null;
    if (!$file || $file['error']!==UPLOAD_ERR_OK) throw new DomainException('Неуспешно качване на файла.');
    if($file['size']<=0 || $file['size']>$max || !is_uploaded_file($file['tmp_name']))throw new DomainException('Невалиден файл или размер над 5 MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if(!isset($allowed[$mime]))throw new DomainException('Неподдържан формат на файла.');
    $filename=bin2hex(random_bytes(20)).'.'.$allowed[$mime];
    $dir=upload_dir();
    if(!is_dir($dir))mkdir($dir,0750,true);
    if(!move_uploaded_file($file['tmp_name'],$dir.'/'.$filename))throw new RuntimeException('Неуспешно съхранение на файла.');
    return [$filename,$mime,(int)$file['size'],substr(basename((string)$file['name']),0,250)];
}
function do_action(string $action): never {
    assert_post();
    if($action==='login'){
        $email=str_post('email');$password=(string)($_POST['password']??'');
        $attempt=$_SESSION['attempts']??['count'=>0,'since'=>time()];
        if(time()-(int)$attempt['since']>900)$attempt=['count'=>0,'since'=>time()];
        if($attempt['count']>=8)throw new DomainException('Твърде много опити за вход. Опитайте след 15 минути.');
        $user=one_row('SELECT * FROM users WHERE email=? AND active=1',[$email]);
        if(!$user||!password_verify($password,$user['password_hash'])){
            $attempt['count']++;$_SESSION['attempts']=$attempt;throw new DomainException('Невалиден имейл или парола.');
        }
        session_regenerate_id(true);unset($_SESSION['attempts']);
        $_SESSION['user']=['id'=>(int)$user['id'],'name'=>$user['name'],'email'=>$user['email'],'role'=>$user['role']];
        audit('login','users',(int)$user['id']);go($user['role']==='client'?'favorites':'dashboard');
    }
    if($action==='logout'){
        if(current_user())audit('logout','users',(int)current_user()['id']);
        $_SESSION=[];session_regenerate_id(true);session_destroy();header('Location: '.route('catalog'));exit;
    }
    $u=only_roles('admin','broker');
    switch($action){
    case 'property_save':
        $id=int_post('id');
        $data=[
            'ref_code'=>Rules::required(str_post('ref_code'),'Код на оферта',32),
            'title'=>Rules::required(str_post('title'),'Заглавие'),
            'deal_type'=>enum_post('deal_type',DEAL_TYPES),
            'type'=>enum_post('type',PROPERTY_TYPES),
            'city'=>Rules::required(str_post('city'),'Град',90),
            'neighborhood'=>str_post('neighborhood')?:null,
            'address'=>Rules::required(str_post('address'),'Адрес',255),
            'area'=>Rules::nonNegative(str_post('area'),'Площ',true),
            'rooms'=>str_post('rooms')===''?null:(int)Rules::nonNegative(str_post('rooms'),'Стаи'),
            'bedrooms'=>str_post('bedrooms')===''?null:(int)Rules::nonNegative(str_post('bedrooms'),'Спални'),
            'floor_no'=>str_post('floor_no')===''?null:(int)str_post('floor_no'),
            'price'=>Rules::nonNegative(str_post('price'),'Цена',true),
            'description'=>str_post('description'),
            'owner_name'=>Rules::required(str_post('owner_name'),'Собственик'),
            'owner_phone'=>Rules::required(str_post('owner_phone'),'Телефон на собственика',32),
            'broker_id'=>broker_for_property_form(),
        ];
        if($data['area']<=0 || $data['price']<=0)throw new DomainException('Площта и цената трябва да са положителни.');
        if($id){
            $old=property_record($id);
            if(in_array($old['status'],['sold','rented'],true) && !is_admin())throw new DomainException('Приключен имот може да се редактира само от администратор.');
            $columns=array_keys($data);$set=implode(', ',array_map(fn($k)=>"`$k`=?",$columns));
            run_sql('UPDATE properties SET '.$set.' WHERE id=?',[...array_values($data),$id]);
            audit('update','properties',$id);flash('Промените са записани.');go('property',['id'=>$id]);
        }
        $columns=array_keys($data);$names=implode(',',array_map(fn($s)=>"`$s`",$columns));
        $marks=implode(',',array_fill(0,count($columns),'?'));
        run_sql('INSERT INTO properties ('.$names.') VALUES ('.$marks.')',array_values($data));
        $new=(int)database()->lastInsertId();audit('create','properties',$new);flash('Имотът е добавен успешно.');go('property',['id'=>$new]);
    case 'property_delete':
        $id=int_post('id');$p=property_record($id);
        if((int)value_of('SELECT COUNT(*) FROM viewings WHERE property_id=?',[$id])>0 ||
           (int)value_of('SELECT COUNT(*) FROM deals WHERE property_id=?',[$id])>0 ||
           (int)value_of('SELECT COUNT(*) FROM documents WHERE property_id=?',[$id])>0)
           throw new DomainException('Имот с огледи, сделки или документи не може да се изтрие окончателно. Използвайте архивиране.');
        $photos=all_rows('SELECT stored_filename FROM property_photos WHERE property_id=?',[$id]);
        run_sql('DELETE FROM properties WHERE id=?',[$id]);
        foreach($photos as $ph)@unlink(dirname(__DIR__).'/storage/uploads/'.basename($ph['stored_filename']));
        audit('delete','properties',$id);flash('Имотът е изтрит.');go('properties');
    case 'photo_delete':
        $photo=one_row('SELECT ph.*,p.broker_id FROM property_photos ph JOIN properties p ON p.id=ph.property_id WHERE ph.id=?',[int_post('id')]);
        check_access($photo);
        run_sql('DELETE FROM property_photos WHERE id=?',[$photo['id']]);
        @unlink(dirname(__DIR__).'/storage/uploads/'.basename($photo['stored_filename']));
        audit('delete','property_photos',(int)$photo['id']);flash('Снимката е премахната.');go('property',['id'=>$photo['property_id']]);
    case 'property_status':
        $id=int_post('id');$p=property_record($id);$status=enum_post('status',PROPERTY_STATUSES);
        if(!in_array($status,['active','reserved','archived'],true))throw new DomainException('Статус „продаден/отдаден“ се задава само при сделка.');
        if(in_array($p['status'],['sold','rented'],true))throw new DomainException('Приключен имот не може да бъде отворен отново.');
        run_sql('UPDATE properties SET status=? WHERE id=?',[$status,$id]);audit('status','properties',$id);flash('Статусът е обновен.');go('property',['id'=>$id]);
    case 'property_photo':
        $id=int_post('property_id');property_record($id);
        [$filename,$mime]=$file=upload_secure('photo',['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']);
        try{run_sql('INSERT INTO property_photos(property_id,stored_filename,mime_type) VALUES(?,?,?)',[$id,$filename,$mime]);}catch(Throwable $e){@unlink(dirname(__DIR__).'/storage/uploads/'.$filename);throw $e;}
        audit('upload','property_photos',(int)database()->lastInsertId());flash('Снимката е качена.');go('property',['id'=>$id]);
    case 'client_save':
        $id=int_post('id');$data=[
            'name'=>Rules::required(str_post('name'),'Име'),
            'phone'=>Rules::required(str_post('phone'),'Телефон',32),
            'email'=>str_post('email')?:null,
            'type'=>enum_post('type',CLIENT_TYPES),
            'notes'=>str_post('notes'),
            'broker_id'=>is_manager()?int_post('broker_id'):(int)$u['id']
        ];
        if($data['email']!==null&&!filter_var($data['email'],FILTER_VALIDATE_EMAIL))throw new DomainException('Невалиден имейл.');
        require_active_broker($data['broker_id']);
        if($id){client_record($id);run_sql('UPDATE clients SET name=?,phone=?,email=?,type=?,notes=?,broker_id=? WHERE id=?',[...array_values($data),$id]);audit('update','clients',$id);flash('Клиентът е обновен.');go('client',['id'=>$id]);}
        run_sql('INSERT INTO clients(name,phone,email,type,notes,broker_id) VALUES(?,?,?,?,?,?)',array_values($data));$new=(int)database()->lastInsertId();audit('create','clients',$new);flash('Клиентът е добавен.');go('client',['id'=>$new]);
    case 'client_delete':
        $client=client_record(int_post('id'));
        if((int)value_of('SELECT COUNT(*) FROM viewings WHERE client_id=?',[$client['id']])>0 ||
           (int)value_of('SELECT COUNT(*) FROM deals WHERE client_id=?',[$client['id']])>0)
            throw new DomainException('Клиент с огледи или сделки не може да бъде изтрит. Запазете историята.');
        run_sql('DELETE FROM clients WHERE id=?',[$client['id']]);audit('delete','clients',(int)$client['id']);
        flash('Клиентът е изтрит.');go('clients');
    case 'requirement_save':
        $id=int_post('id');$client=client_record(int_post('client_id'));
        $data=[
            'client_id'=>(int)$client['id'],
            'deal_type'=>enum_post('deal_type',DEAL_TYPES),
            'type'=>str_post('type')?:null,
            'city'=>str_post('city')?:null,
            'neighborhood'=>str_post('neighborhood')?:null,
            'min_price'=>Rules::nonNegative(str_post('min_price'),'Минимална цена'),
            'max_price'=>Rules::nonNegative(str_post('max_price'),'Максимална цена'),
            'min_area'=>Rules::nonNegative(str_post('min_area'),'Минимална площ'),
            'min_rooms'=>str_post('min_rooms')===''?null:(int)Rules::nonNegative(str_post('min_rooms'),'Минимум стаи'),
            'notes'=>str_post('notes')
        ];
        if($data['type']!==null&&!array_key_exists($data['type'],PROPERTY_TYPES))throw new DomainException('Невалиден тип имот.');
        if($data['max_price']!==null&&$data['min_price']!==null&&$data['max_price']<$data['min_price'])throw new DomainException('Максималната цена е по-ниска от минималната.');
        if($id){$old=one_row('SELECT * FROM requirements WHERE id=?',[$id]);if(!$old||$old['client_id']!=$client['id'])fail(404,'Заявката не е намерена.');$keys=array_keys($data);$set=implode(',',array_map(fn($k)=>"$k=?",$keys));run_sql("UPDATE requirements SET $set WHERE id=?",[...array_values($data),$id]);audit('update','requirements',$id);}
        else{$keys=array_keys($data);run_sql('INSERT INTO requirements('.implode(',',$keys).') VALUES('.implode(',',array_fill(0,count($keys),'?')).')',array_values($data));audit('create','requirements',(int)database()->lastInsertId());}
        flash('Критериите са записани.');go('client',['id'=>$client['id']]);
    case 'requirement_delete':
        $id=int_post('id');$r=one_row('SELECT * FROM requirements WHERE id=?',[$id]);if(!$r)fail(404,'Критериите не са намерени.');client_record((int)$r['client_id']);run_sql('DELETE FROM requirements WHERE id=?',[$id]);audit('delete','requirements',$id);flash('Критериите са изтрити.');go('client',['id'=>$r['client_id']]);
    case 'interest_save':
        $client=client_record(int_post('client_id'));$property=property_record(int_post('property_id'));if(!in_array($property['status'],['active','reserved'],true))throw new DomainException('Имотът не е активен.');$status=enum_post('status',['suggested'=>'Предложен','interested'=>'Интерес','viewed'=>'Показан','declined'=>'Отказан']);
        run_sql('INSERT INTO interests(client_id,property_id,broker_id,status,notes) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status), notes=VALUES(notes)',[(int)$client['id'],(int)$property['id'],(int)$u['id'],$status,str_post('notes')]);
        audit('save','interests');flash('Интересът към имота е записан.');go('client',['id'=>$client['id']]);
    case 'viewing_save':
        $property=property_record(int_post('property_id'));$client=client_record(int_post('client_id'));
        if(!in_array($property['status'],['active','reserved'],true))throw new DomainException('Не може да се планира оглед за приключен имот.');
        $broker=(int)$property['broker_id'];
        $raw=str_post('starts_at');
        if(!Rules::isValidDate($raw,'Y-m-d\TH:i'))throw new DomainException('Невалидна дата и час.');
        $starts=str_replace('T',' ',$raw).':00';$dur=int_post('duration_min');
        if($dur<15||$dur>240)throw new DomainException('Продължителността е между 15 и 240 минути.');
        if(strtotime($starts)<time())throw new DomainException('Огледът трябва да е в бъдещето.');
        $db=database();$db->beginTransaction();
        try{
            // Serialize booking attempts for the broker to prevent simultaneous double bookings.
            $lock=one_row('SELECT id FROM users WHERE id=? FOR UPDATE',[$broker]);
            if(!$lock)throw new DomainException('Липсва брокер.');
            $lockedProperty=one_row('SELECT id,status FROM properties WHERE id=? FOR UPDATE',[(int)$property['id']]);
            if(!$lockedProperty||!in_array($lockedProperty['status'],['active','reserved'],true))throw new DomainException('Имотът вече не е активен.');
            $end=date('Y-m-d H:i:s',strtotime($starts)+$dur*60);
            $overlap=value_of("SELECT COUNT(*) FROM viewings WHERE broker_id=? AND status='planned' AND starts_at < ? AND DATE_ADD(starts_at, INTERVAL duration_min MINUTE) > ?",[$broker,$end,$starts]);
            if((int)$overlap>0)throw new DomainException('Конфликт: брокерът вече има оглед в този интервал.');
            run_sql('INSERT INTO viewings(property_id,client_id,broker_id,starts_at,duration_min,note) VALUES(?,?,?,?,?,?)',[$property['id'],$client['id'],$broker,$starts,$dur,str_post('note')]);
            $id=(int)$db->lastInsertId();$db->commit();audit('create','viewings',$id);flash('Огледът е планиран.');go('viewings');
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    case 'viewing_status':
        $id=int_post('id');$v=check_access(one_row('SELECT * FROM viewings WHERE id=?',[$id]));
        if($v['status']!=='planned')throw new DomainException('Статусът вече е приключен.');
        $status=enum_post('status',VIEWING_STATUSES);
        if($status==='planned')throw new DomainException('Изберете нов статус.');
        run_sql('UPDATE viewings SET status=? WHERE id=? AND status=?',[$status,$id,'planned']);audit('status','viewings',$id);flash('Статусът на огледа е променен.');go('viewings');
    case 'deal_save':
        $property=property_record(int_post('property_id'));$client=client_record(int_post('client_id'));
        $amount=Rules::nonNegative(str_post('amount'),'Стойност',true);
        $percent=Rules::nonNegative(str_post('commission_percent'),'Комисионна',true);
        if($amount<=0)throw new DomainException('Стойността трябва да е положителна.');
        $commission=Rules::commission($amount,$percent);
        $date=str_post('deal_date');if(!Rules::isValidDate($date))throw new DomainException('Невалидна дата.');
        $status=enum_post('status',['pending'=>'В процес','completed'=>'Приключена']);
        $db=database();$db->beginTransaction();
        try{
            $locked=one_row('SELECT id,status,deal_type,broker_id FROM properties WHERE id=? FOR UPDATE',[$property['id']]);
            if(!$locked||!in_array($locked['status'],['active','reserved'],true))throw new DomainException('Имотът вече е неактивен.');
            run_sql('INSERT INTO deals(property_id,client_id,broker_id,type,amount,commission_percent,commission_amount,deal_date,status,note) VALUES(?,?,?,?,?,?,?,?,?,?)',[
                $property['id'],$client['id'],$locked['broker_id'],$locked['deal_type'],$amount,$percent,$commission,$date,$status,str_post('note')
            ]);
            $new=(int)$db->lastInsertId();
            if($status==='completed'){
                run_sql('UPDATE properties SET status=? WHERE id=?',[Rules::completedStatus($locked['deal_type']),$property['id']]);
                run_sql("UPDATE deals SET status='cancelled' WHERE property_id=? AND id<>? AND status='pending'",[$property['id'],$new]);
            }
            $db->commit();audit('create','deals',$new);flash('Сделката е записана успешно.');go('deals');
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    case 'deal_status':
        $id=int_post('id');$deal=check_access(one_row('SELECT * FROM deals WHERE id=?',[$id]));
        if($deal['status']!=='pending')throw new DomainException('Могат да се променят само сделки в процес.');
        $status=enum_post('status',['completed'=>'Приключена','cancelled'=>'Отказана']);
        $db=database();$db->beginTransaction();
        try{
            $p=one_row('SELECT id,status,deal_type FROM properties WHERE id=? FOR UPDATE',[(int)$deal['property_id']]);
            if($status==='completed'){
                if(!$p||!in_array($p['status'],['active','reserved'],true))throw new DomainException('Имотът е затворен чрез друга сделка.');
                run_sql('UPDATE properties SET status=? WHERE id=?',[Rules::completedStatus($deal['type']),$p['id']]);
                run_sql("UPDATE deals SET status='cancelled' WHERE property_id=? AND id<>? AND status='pending'",[$p['id'],$id]);
            }
            run_sql("UPDATE deals SET status=? WHERE id=? AND status='pending'",[$status,$id]);$db->commit();audit('status','deals',$id);flash('Сделката е обновена.');go('deals');
        }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
    case 'expense_save':
        only_roles('admin');
        $title=Rules::required(str_post('title'),'Описание');$cat=enum_post('category',['advertising'=>'Реклама','office'=>'Офис','transport'=>'Транспорт','maintenance'=>'Поддръжка','other'=>'Друго']);
        $amount=Rules::nonNegative(str_post('amount'),'Разход',true);if($amount<=0)throw new DomainException('Сумата трябва да е положителна.');
        $date=str_post('expense_date');if(!Rules::isValidDate($date))throw new DomainException('Невалидна дата.');
        run_sql('INSERT INTO expenses(title,category,amount,expense_date,creator_id) VALUES(?,?,?,?,?)',[$title,$cat,$amount,$date,$u['id']]);audit('create','expenses',(int)database()->lastInsertId());flash('Разходът е добавен.');go('finance');
    case 'expense_delete':
        only_roles('admin');$id=int_post('id');
        if(!one_row('SELECT id FROM expenses WHERE id=?',[$id]))fail(404,'Разходът не е намерен.');
        run_sql('DELETE FROM expenses WHERE id=?',[$id]);audit('delete','expenses',$id);
        flash('Разходът е изтрит.');go('finance');
    case 'employee_save':
        only_roles('admin');
        $name=Rules::required(str_post('name'),'Име');$email=str_post('email');$password=(string)($_POST['password']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL))throw new DomainException('Невалиден имейл.');
        if(strlen($password)<10)throw new DomainException('Паролата трябва да е поне 10 символа.');
        $role=enum_post('role',['broker'=>'Брокер']);
        run_sql('INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,?)',[$name,$email,str_post('phone'),password_hash($password,PASSWORD_DEFAULT),$role]);
        audit('create','users',(int)database()->lastInsertId());flash('Служителят е добавен.');go('employees');
    case 'employee_status':
        only_roles('admin');$id=int_post('id');
        if($id===(int)$u['id'])throw new DomainException('Не може да деактивирате своя профил.');
        $usr=one_row("SELECT * FROM users WHERE id=? AND role='broker'",[$id]);if(!$usr)fail(404,'Брокерът не е намерен.');
        if((int)$usr['active']===1){
            $assigned=(int)value_of("SELECT COUNT(*) FROM properties WHERE broker_id=? AND status IN ('active','reserved')",[$id]);
            if($assigned>0)throw new DomainException('Първо прехвърлете активните имоти на друг брокер.');
        }
        run_sql('UPDATE users SET active=? WHERE id=?',[(int)!$usr['active'],$id]);audit('status','users',$id);flash('Статусът е променен.');go('employees');
    case 'document_delete':
        $id=int_post('id');$doc=one_row('SELECT f.*,p.broker_id property_broker,d.broker_id deal_broker FROM documents f LEFT JOIN properties p ON p.id=f.property_id LEFT JOIN deals d ON d.id=f.deal_id WHERE f.id=?',[$id]);
        if(!$doc)fail(404,'Документът не е намерен.');
        if(!is_manager() && ((int)$doc['creator_id']!==(int)$u['id'] ||
            ((int)($doc['property_broker']??0)!==(int)$u['id'] && (int)($doc['deal_broker']??0)!==(int)$u['id'])))
            fail(403,'Нямате права да изтриете документа.');
        run_sql('DELETE FROM documents WHERE id=?',[$id]);
        @unlink(dirname(__DIR__).'/storage/uploads/'.basename($doc['stored_filename']));
        audit('delete','documents',$id);flash('Документът е изтрит.');go('documents');
    case 'document_upload':
        $pid=int_post('property_id');$did=int_post('deal_id');
        if(!$pid&&!$did)throw new DomainException('Изберете имот или сделка.');
        if($pid)property_record($pid);
        if($did){$deal=check_access(one_row('SELECT * FROM deals WHERE id=?',[$did]));if($pid&&$deal['property_id']!=$pid)throw new DomainException('Сделката не принадлежи към избрания имот.');}
        $title=Rules::required(str_post('title'),'Име на документ');
        [$filename,$mime,$size,$original]=upload_secure('document',['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png']);
        try{
            run_sql('INSERT INTO documents(title,property_id,deal_id,stored_filename,original_filename,mime_type,byte_size,creator_id) VALUES(?,?,?,?,?,?,?,?)',[
                $title,$pid?:null,$did?:null,$filename,$original,$mime,$size,$u['id']
            ]);
        }catch(Throwable $e){@unlink(dirname(__DIR__).'/storage/uploads/'.$filename);throw $e;}
        audit('upload','documents',(int)database()->lastInsertId());flash('Документът е качен.');go('documents');
    default: fail(404,'Непознато действие.');
    }
}
