<?php
declare(strict_types=1);

/** Public-facing client portal. Database writes are only in public_action(), with server-side role checks. */
function public_action(string $action): never {
    assert_post();
    if ($action === 'register') {
        if (current_user()) go(is_staff() ? 'dashboard' : 'favorites');
        $name = Rules::required(str_post('name'),'Име',150);
        $email = strtolower(str_post('email'));
        $password = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');
        if (!filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($email)>190) throw new DomainException('Въведете валиден имейл.');
        if (strlen($password)<10 || strlen($password)>128) throw new DomainException('Паролата трябва да е между 10 и 128 символа.');
        if (!hash_equals($password,$confirm)) throw new DomainException('Паролите не съвпадат.');
        if (one_row('SELECT id FROM users WHERE email=?',[$email])) throw new DomainException('Вече има профил с този имейл.');
        // Role is NOT accepted from client input. Every public signup gets the lowest permission level.
        run_sql("INSERT INTO users(name,email,password_hash,role,active) VALUES(?, ?, ?, 'client', 1)",[
            $name,$email,password_hash($password,PASSWORD_DEFAULT)
        ]);
        $id=(int)database()->lastInsertId();
        session_regenerate_id(true);
        $_SESSION['user']=['id'=>$id,'name'=>$name,'email'=>$email,'role'=>'client'];
        audit('register','users',$id);
        flash('Добре дошли! Вече можете да запазвате любими имоти.');
        go('favorites');
    }
    if ($action === 'favorite_toggle') {
        $u=only_roles('client');
        $pid=int_post('property_id');
        if($pid<=0)throw new DomainException('Невалиден имот.');
        $property=one_row("SELECT id FROM properties WHERE id=? AND status='active'",[$pid]);
        if(!$property)throw new DomainException('Тази обява вече не е активна.');
        $existing=one_row('SELECT id FROM favorites WHERE user_id=? AND property_id=?',[$u['id'],$pid]);
        if($existing){run_sql('DELETE FROM favorites WHERE user_id=? AND property_id=?',[$u['id'],$pid]);flash('Имотът е премахнат от любими.');}
        else {run_sql('INSERT IGNORE INTO favorites(user_id,property_id) VALUES(?,?)',[$u['id'],$pid]);flash('Имотът е добавен към любими.');}
        // Avoid arbitrary redirects: only predefined pages, never external URLs.
        $from = str_post('return_to');
        if($from === 'favorites')go('favorites');
        if($from === 'catalog')go('catalog');
        go('public_property',['id'=>$pid]);
    }
    fail(404,'Непознато действие.');
}

function public_layout_start(string $title): void {
    $user=current_user(); $flash=take_flash();
    $favcount=$user && $user['role']==='client' ? (int)value_of("SELECT COUNT(*) FROM favorites f JOIN properties p ON p.id=f.property_id WHERE f.user_id=? AND p.status='active'",[$user['id']]) : 0;
    ?><!doctype html><html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=esc($title)?> · Имоти Томов</title><meta name="description" content="Имоти Томов — предложения за продажба и под наем. Разгледайте активните ни имоти и запазете любимите си обяви."><link rel="stylesheet" href="<?=esc(base_url())?>/assets/css/style.css"><link rel="stylesheet" href="<?=esc(base_url())?>/assets/css/public.css"><script defer src="<?=esc(base_url())?>/assets/js/app.js"></script></head>
    <body class="public-site"><header class="site-header"><div class="site-header-inner"><a class="site-brand" href="<?=esc(route('catalog'))?>"><span class="site-logo-icon">⌂</span><span><b>Имоти Томов</b><small>Система за недвижими имоти</small></span></a><nav class="site-links" aria-label="Навигация"><a href="<?=esc(route('catalog'))?>">Всички имоти</a><?php if($user && $user['role']==='client'):?><a href="<?=esc(route('favorites'))?>">♡ Любими <span class="site-count"><?=$favcount?></span></a><?php endif;?><?php if($user && is_staff()):?><a href="<?=esc(route('dashboard'))?>">Панел за служители</a><?php endif;?></nav><div class="site-account"><?php if($user):?><span class="site-welcome">Здравейте, <?=esc($user['name'])?></span><?php form_open('logout','public-logout');?><button type="submit" class="site-outline">Изход</button></form><?php else:?><a class="site-outline" href="<?=esc(route('login'))?>">Вход</a><a class="site-primary" href="<?=esc(route('register'))?>">Регистрация</a><?php endif;?></div></div></header><main class="site-main">
    <?php if($flash):?><div class="site-flash <?=esc($flash['kind'])?>" role="alert"><?=esc($flash['message'])?><button type="button" class="notice-close" aria-label="Затвори">×</button></div><?php endif; ?><?php
}
function public_layout_end(): void {
    echo '</main><footer class="site-footer"><div><b>⌂ Имоти Томов</b><span>Система за недвижими имоти · Курсов проект, Вариант 13</span></div><small>© '.date('Y').' Имоти Томов</small></footer></body></html>';
}
function public_image(array $property, string $class=''): void {
    if(!empty($property['photo_id'])){
        echo '<img class="'.esc($class).'" src="'.esc(route('photo',['id'=>(int)$property['photo_id']])).'" alt="'.esc($property['title']).'" loading="lazy">';
    }else{
        echo '<div class="site-photo-placeholder '.esc($class).'"><span>⌂</span><small>ИМОТИ ТОМОВ</small></div>';
    }
}
function public_property_card(array $p, array $favLookup=[], string $returnTo='catalog'): void {
    $url=route('public_property',['id'=>(int)$p['id']]);
    ?><article class="listing-card"><a class="listing-image" href="<?=esc($url)?>"><?php public_image($p); ?><span class="listing-chip"><?=esc(label_from(DEAL_TYPES,$p['deal_type']))?></span></a><div class="listing-content"><div class="listing-price"><?=amount($p['price'])?> <small><?=($p['deal_type']==='rent')?'/ месец':''?></small></div><a class="listing-title" href="<?=esc($url)?>"><?=esc($p['title'])?></a><div class="listing-location">⌖ <?=esc($p['city'])?><?=!empty($p['neighborhood'])?', '.esc($p['neighborhood']):''?></div><div class="listing-attributes"><span>▣ <?=esc($p['area'])?> м²</span><span>⌂ <?=esc(label_from(PROPERTY_TYPES,$p['type']))?></span><?php if($p['rooms']):?><span>▤ <?=esc($p['rooms'])?> стаи</span><?php endif;?></div><div class="listing-bottom"><span class="listing-ref">Оферта <?=esc($p['ref_code'])?></span><a href="<?=esc($url)?>">Детайли →</a></div>
    <?php if((current_user()['role']??'')==='client'):?>
      <?php form_open('favorite_toggle','listing-save');?><input type="hidden" name="property_id" value="<?=esc($p['id'])?>"><input type="hidden" name="return_to" value="<?=esc($returnTo)?>"><button type="submit" class="listing-save-button"><?=isset($favLookup[(int)$p['id']])?'♥ Премахни от любими':'♡ Запази в любими'?></button></form>
    <?php elseif(!current_user()):?><a class="listing-save-button listing-save" href="<?=esc(route('login'))?>">♡ Запази в любими</a><?php endif; ?></div></article><?php
}
function page_catalog(): void {
    $where=" WHERE p.status='active'";$args=[];
    $q=trim((string)($_GET['q']??''));$city=trim((string)($_GET['city']??''));
    if($q!==''){$where.=' AND (p.title LIKE ? OR p.description LIKE ? OR p.ref_code LIKE ?)';array_push($args,'%'.$q.'%','%'.$q.'%','%'.$q.'%');}
    if($city!==''){$where.=' AND (p.city LIKE ? OR p.neighborhood LIKE ?)';array_push($args,'%'.$city.'%','%'.$city.'%');}
    foreach(['type'=>PROPERTY_TYPES,'deal_type'=>DEAL_TYPES] as $field=>$choices){$v=(string)($_GET[$field]??'');if(isset($choices[$v])){$where.=" AND p.$field=?";$args[]=$v;}}
    foreach(['min_price'=>'>=','max_price'=>'<='] as $key=>$cmp){$v=(string)($_GET[$key]??'');if($v!==''&&is_numeric($v)&&(float)$v>=0){$where.=" AND p.price $cmp ?";$args[]=(float)$v;}}
    $rows=all_rows("SELECT p.*, (SELECT ph.id FROM property_photos ph WHERE ph.property_id=p.id ORDER BY ph.id LIMIT 1) photo_id FROM properties p".$where." ORDER BY p.created_at DESC LIMIT 60",$args);
    ?><section class="site-hero"><div class="site-hero-shine"></div><div class="hero-text"><span class="hero-tag">ДОБРЕ ДОШЛИ В ИМОТИ ТОМОВ</span><h1>Открийте имота, който да наречете <em>дом.</em></h1><p>Разгледайте внимателно подбраните ни предложения за продажба и под наем.</p><div class="hero-points"><span>✓ Продажби</span><span>✓ Наеми</span><span>✓ Професионално обслужване</span></div></div><div class="hero-art"><div class="hero-house">⌂</div><div class="hero-art-card">Вашият нов дом<br><b>започва оттук.</b></div></div></section>
    <section class="catalog-search"><form method="get" action="<?=esc(base_url())?>/index.php" class="catalog-search-form"><input type="hidden" name="page" value="catalog"><label>Ключова дума<input type="search" name="q" value="<?=esc($q)?>" placeholder="Какво търсите?"></label><label>Град / квартал<input name="city" value="<?=esc($city)?>" placeholder="Напр. Стара Загора"></label><label>Тип имот<select name="type"><?=select_options([''=>'Всички']+PROPERTY_TYPES,$_GET['type']??'')?></select></label><label>Вид оферта<select name="deal_type"><?=select_options([''=>'Всички']+DEAL_TYPES,$_GET['deal_type']??'')?></select></label><label>Цена до (€)<input type="number" step="0.01" min="0" name="max_price" value="<?=esc($_GET['max_price']??'')?>" placeholder="Макс. цена"></label><button class="site-primary" type="submit">⌕ Търси</button></form></section>
    <?php $savedLookup=[];if((current_user()['role']??'')==='client')$savedLookup=array_fill_keys(array_column(all_rows('SELECT property_id FROM favorites WHERE user_id=?',[current_user()['id']]),'property_id'),true);?>
    <section class="site-section"><div class="site-section-head"><div><div class="eyebrow">НАШИТЕ ПРЕДЛОЖЕНИЯ</div><h2>Актуални имоти</h2><p>Само активни обяви · <?=count($rows)?> резултата</p></div><a href="<?=esc(route('catalog'))?>">Изчисти филтрите ↗</a></div><div class="listing-grid"><?php foreach($rows as $p)public_property_card($p,$savedLookup,'catalog');?></div><?php if(!$rows):?><div class="site-empty"><b>Няма намерени предложения</b><p>Опитайте да промените избраните критерии.</p><a class="site-primary" href="<?=esc(route('catalog'))?>">Всички имоти</a></div><?php endif;?></section><?php
}
function page_public_property(): void {
    $id=(int)($_GET['id']??0);$p=one_row("SELECT p.*,u.name broker_name,u.phone broker_phone,u.email broker_email FROM properties p JOIN users u ON u.id=p.broker_id WHERE p.id=? AND p.status='active'",[$id]);
    if(!$p)fail(404,'Обявата не е налична.');
    $photos=all_rows('SELECT id FROM property_photos WHERE property_id=? ORDER BY id',[$id]);
    $u=current_user();$saved=$u && $u['role']==='client' ? (bool)one_row('SELECT id FROM favorites WHERE user_id=? AND property_id=?',[$u['id'],$id]) : false;
    ?><div class="site-breadcrumb"><a href="<?=esc(route('catalog'))?>">Имоти</a> › <?=esc($p['ref_code'])?></div><div class="public-detail-head"><div><div class="eyebrow"><?=esc(label_from(DEAL_TYPES,$p['deal_type']))?> · <?=esc($p['ref_code'])?></div><h1><?=esc($p['title'])?></h1><p>⌖ <?=esc($p['city'])?><?=!empty($p['neighborhood'])?', '.esc($p['neighborhood']):''?></p></div><strong><?=amount($p['price'])?><?=($p['deal_type']==='rent')?' <small>/ месец</small>':''?></strong></div><div class="public-detail-grid"><div class="public-main-column"><section class="public-photo-main"><?php if($photos):?><img src="<?=esc(route('photo',['id'=>$photos[0]['id']]))?>" alt="<?=esc($p['title'])?>"><?php else:?><?php public_image($p);?><?php endif;?></section><?php if(count($photos)>1):?><div class="public-photo-thumbs"><?php foreach(array_slice($photos,1,8) as $ph):?><a href="<?=esc(route('photo',['id'=>$ph['id']]))?>" target="_blank" rel="noopener"><img src="<?=esc(route('photo',['id'=>$ph['id']]))?>" loading="lazy" alt="Снимка на имота"></a><?php endforeach;?></div><?php endif;?><section class="site-white-panel"><h2>Характеристики</h2><div class="public-facts"><div><span>Тип имот</span><b><?=esc(label_from(PROPERTY_TYPES,$p['type']))?></b></div><div><span>Площ</span><b><?=esc($p['area'])?> м²</b></div><div><span>Стаи</span><b><?=esc($p['rooms']??'—')?></b></div><div><span>Спални</span><b><?=esc($p['bedrooms']??'—')?></b></div><div><span>Етаж</span><b><?=esc($p['floor_no']??'—')?></b></div><div><span>Оферта</span><b><?=esc(label_from(DEAL_TYPES,$p['deal_type']))?></b></div></div><h2>Описание</h2><p class="public-description"><?=nl2br(esc($p['description']?:'Няма добавено описание.'))?></p></section></div><aside class="public-side"><div class="site-white-panel"><h2>Харесва ви този имот?</h2><p class="muted">Добавете го към любимите си предложения, за да го откриете по-лесно по-късно.</p><?php if($u&&$u['role']==='client'):?><?php form_open('favorite_toggle');?><input type="hidden" name="property_id" value="<?=$id?>"><input type="hidden" name="return_to" value="public_property"><button class="site-primary full" type="submit"><?=$saved?'♥ Премахни от любими':'♡ Запази в любими'?></button></form><?php elseif(!$u):?><a class="site-primary full" href="<?=esc(route('login'))?>">♡ Влезте, за да запазите</a><p class="site-small">Нямате профил? <a href="<?=esc(route('register'))?>">Регистрация</a></p><?php else:?><p class="site-small">Можете да разглеждате предложенията и като служител.</p><?php endif;?></div><div class="site-white-panel"><h2>Контакт с брокер</h2><div class="broker-avatar">♙</div><b><?=esc($p['broker_name'])?></b><p class="muted">Отговорен брокер</p><a class="broker-phone" href="tel:<?=esc(preg_replace('/[^0-9+]/','',$p['broker_phone']??''))?>"><?=esc($p['broker_phone']?:'Телефон при запитване')?></a><a class="broker-email" href="mailto:<?=esc($p['broker_email'])?>"><?=esc($p['broker_email'])?></a></div></aside></div><?php
}
function page_favorites(): void {
    $u=only_roles('client');
    $rows=all_rows("SELECT p.*, (SELECT ph.id FROM property_photos ph WHERE ph.property_id=p.id ORDER BY ph.id LIMIT 1) photo_id FROM favorites f JOIN properties p ON p.id=f.property_id WHERE f.user_id=? AND p.status='active' ORDER BY f.saved_at DESC",[$u['id']]);
    $savedLookup=array_fill_keys(array_column($rows,'id'),true);
    ?><section class="site-section"><div class="site-section-head"><div><div class="eyebrow">МОЯТ ПРОФИЛ</div><h1>Любими имоти ♡</h1><p>Вашите запазени активни предложения · <?=count($rows)?> имота</p></div><a href="<?=esc(route('catalog'))?>">Разгледай още →</a></div><div class="listing-grid"><?php foreach($rows as $p)public_property_card($p,$savedLookup,'favorites');?></div><?php if(!$rows):?><div class="site-empty"><b>Все още нямате любими имоти</b><p>Разгледайте предложенията и изберете тези, които ви харесват.</p><a class="site-primary" href="<?=esc(route('catalog'))?>">Разгледай имотите</a></div><?php endif;?></section><?php
}
function page_register(): void {
    if(current_user())go(is_staff()?'dashboard':'favorites');
    ?><section class="public-auth"><div class="public-auth-art"><span class="hero-tag">ИМОТИ ТОМОВ</span><h2>Намерете своето място.</h2><p>Създайте безплатен профил и запазвайте любимите си имоти на едно място.</p><div class="public-auth-symbol">⌂</div></div><div class="public-auth-form"><div class="eyebrow">НОВ ПРОФИЛ</div><h1>Регистрация за клиенти</h1><p>Регистрацията дава достъп само до разглеждане и запазване на обяви.</p><?php form_open('register');?><label class="field"><span>Име и фамилия *</span><input name="name" autocomplete="name" required maxlength="150"></label><label class="field"><span>Имейл *</span><input type="email" name="email" autocomplete="email" required maxlength="190"></label><label class="field"><span>Парола (10+ символа) *</span><input type="password" name="password" autocomplete="new-password" minlength="10" maxlength="128" required></label><label class="field"><span>Повторете паролата *</span><input type="password" name="confirm_password" autocomplete="new-password" minlength="10" maxlength="128" required></label><button type="submit" class="site-primary full">Създай клиентски профил</button></form><p class="site-small">Вече имате профил? <a href="<?=esc(route('login'))?>">Влезте</a></p></div></section><?php
}
