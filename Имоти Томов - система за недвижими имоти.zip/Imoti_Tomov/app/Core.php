<?php
declare(strict_types=1);

$config = require __DIR__ . '/config.php';
require_once __DIR__ . '/Rules.php';
date_default_timezone_set('Europe/Sofia');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('imoti_tomov_session');
    session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','samesite'=>'Lax','path'=>'/']);
    session_start();
}
function cfg(string $key): mixed { global $config; return $config[$key]; }
function base_url(): string { return rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/'); }
function route(string $page='dashboard', array $params=[]): string { return base_url().'/index.php?'.http_build_query(['page'=>$page]+$params); }
function esc(mixed $value): string { return htmlspecialchars((string)($value??''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function go(string $page='dashboard', array $params=[]): never { header('Location: '.route($page,$params)); exit; }
function upload_dir(): string { return rtrim((string)cfg('upload_dir'), '/\\'); }
function database(): PDO {
    static $db;
    if (!isset($db)) {
        $dsn = 'mysql:host='.cfg('db_host').';port='.cfg('db_port').';dbname='.cfg('db_name').';charset=utf8mb4';
        $db = new PDO($dsn,(string)cfg('db_user'),(string)cfg('db_password'),[
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false,
        ]);
    }
    return $db;
}
function all_rows(string $sql, array $args=[]): array { $s=database()->prepare($sql);$s->execute($args);return $s->fetchAll(); }
function one_row(string $sql, array $args=[]): ?array { $s=database()->prepare($sql);$s->execute($args);$row=$s->fetch();return $row?:null; }
function value_of(string $sql, array $args=[]): mixed { $s=database()->prepare($sql);$s->execute($args);return $s->fetchColumn(); }
function run_sql(string $sql, array $args=[]): int { $s=database()->prepare($sql);$s->execute($args);return $s->rowCount(); }
function audit(string $action, string $entity, ?int $id=null): void {
    $u=current_user();run_sql('INSERT INTO audit_log(user_id,action,entity,entity_id) VALUES(?,?,?,?)',[$u['id']??null,$action,$entity,$id]);
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function must_login(): array {
    $user=current_user();if(!$user)go('login');
    // Refresh status/role on each request so blocked users lose access immediately.
    $fresh=one_row('SELECT id,name,email,role,active FROM users WHERE id=?',[(int)$user['id']]);
    if(!$fresh || !(int)$fresh['active']){
        $_SESSION=[];session_regenerate_id(true);go('login');
    }
    $_SESSION['user']=['id'=>(int)$fresh['id'],'name'=>$fresh['name'],'email'=>$fresh['email'],'role'=>$fresh['role']];
    return $_SESSION['user'];
}
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }
function is_staff(): bool { return in_array(current_user()['role'] ?? '', ['admin','broker'],true); }
function is_manager(): bool { return is_admin(); } // Compatibility with internal pages: only admin has global rights.
function only_roles(string ...$roles): array { $u=must_login();if(!in_array($u['role'],$roles,true))fail(403,'Нямате права за това действие.');return $u; }
function fail(int $code,string $message): never { http_response_code($code);throw new RuntimeException($message,$code); }
function flash(string $message,string $kind='success'): void { $_SESSION['flash']=['message'=>$message,'kind'=>$kind]; }
function take_flash(): ?array { $f=$_SESSION['flash']??null;unset($_SESSION['flash']);return $f; }
function csrf_token(): string { return $_SESSION['csrf']??=bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.esc(csrf_token()).'">'; }
function assert_post(): void {
    if (($_SERVER['REQUEST_METHOD']??'GET')!=='POST')fail(405,'Неподдържан метод.');
    if(!hash_equals(csrf_token(),(string)($_POST['csrf']??'')))fail(419,'Невалидна или изтекла форма. Презаредете страницата.');
}
function int_post(string $key): int { return filter_var($_POST[$key]??null,FILTER_VALIDATE_INT) ?: 0; }
function str_post(string $key): string { return trim((string)($_POST[$key]??'')); }
function check_access(?array $item, string $ownerKey='broker_id'): array {
    only_roles('admin','broker');
    if(!$item)fail(404,'Записът не е намерен.');
    if(!is_manager() && (int)$item[$ownerKey] !== (int)must_login()['id'])fail(403,'Нямате достъп до този запис.');
    return $item;
}
function property_record(int $id): array { only_roles('admin','broker'); return check_access(one_row('SELECT * FROM properties WHERE id=?',[$id])); }
function client_record(int $id): array { only_roles('admin','broker'); return check_access(one_row('SELECT * FROM clients WHERE id=?',[$id])); }
function own_where(string $alias, array &$args): string {
    only_roles('admin','broker');
    if(is_manager()) return '';
    $args[]=must_login()['id'];
    return ' AND '.$alias.'.broker_id=?';
}
function select_options(array $items, string|int|null $selected=null): string {
    $out='';foreach($items as $key=>$text){$out.='<option value="'.esc((string)$key).'"'.((string)$key===(string)$selected?' selected':'').'>'.esc($text).'</option>';}
    return $out;
}
const PROPERTY_TYPES=['apartment'=>'Апартамент','house'=>'Къща','land'=>'Парцел','office'=>'Офис','shop'=>'Магазин','garage'=>'Гараж','other'=>'Друг'];
const DEAL_TYPES=['sale'=>'Продажба','rent'=>'Наем'];
const PROPERTY_STATUSES=['active'=>'Активен','reserved'=>'Резервиран','sold'=>'Продаден','rented'=>'Отдаден','archived'=>'Архивиран'];
const CLIENT_TYPES=['buyer'=>'Купувач','tenant'=>'Наемател','seller'=>'Продавач','landlord'=>'Наемодател','other'=>'Друг'];
const VIEWING_STATUSES=['planned'=>'Планиран','completed'=>'Проведен','cancelled'=>'Отменен','no_show'=>'Не се е състоял'];
const DEAL_STATUSES=['pending'=>'В процес','completed'=>'Приключена','cancelled'=>'Отказана'];
function enum_post(string $key,array $values): string { $v=str_post($key);if(!array_key_exists($v,$values))throw new DomainException('Невалиден избор за „'.$key.'“.');return $v; }
