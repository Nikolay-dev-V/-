<?php
declare(strict_types=1);
// XAMPP standard: MySQL user=root, password empty. Change before production deployment.
return [
    'db_host' => getenv('EM_DB_HOST') ?: '127.0.0.1',
    'db_port' => getenv('EM_DB_PORT') ?: '3306',
    'db_name' => getenv('EM_DB_NAME') ?: 'estate_manager',
    'db_user' => getenv('EM_DB_USER') ?: 'root',
    'db_password' => getenv('EM_DB_PASSWORD') ?: '',
    'app_name' => 'Имоти Томов',
    // By default, one level outside Apache's htdocs (C:/xampp/Imoti_Tomov_private_uploads).
    'upload_dir' => getenv('EM_UPLOAD_DIR') ?: dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'Imoti_Tomov_private_uploads',
];
