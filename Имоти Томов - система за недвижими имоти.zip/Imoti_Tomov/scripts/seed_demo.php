<?php
declare(strict_types=1);
// CLI only: php scripts/seed_demo.php (after schema import + admin creation).
if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI only');}
require __DIR__.'/../app/Core.php';
try {
    $db=database();
    $admin=one_row("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1");
    if(!$admin)throw new RuntimeException('Първо създайте администратор чрез public/install.php.');
    if((int)value_of('SELECT COUNT(*) FROM properties')>0)throw new RuntimeException('В базата вече има имоти. Демонстрационното зареждане е отказано.');
    $db->beginTransaction();
    $accounts=[];
    foreach([['Мария Петрова','maria.demo@estate.local','broker'],['Георги Иванов','georgi.demo@estate.local','broker'],['Десислава Георгиева','desi.demo@estate.local','broker']] as [$name,$email,$role]){
        $user=one_row('SELECT id FROM users WHERE email=?',[$email]);
        if($user){$id=(int)$user['id'];$password='(вече съществува)';}
        else{
            $password=bin2hex(random_bytes(7));
            run_sql('INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,?)',[$name,$email,'0888000000',password_hash($password,PASSWORD_DEFAULT),$role]);
            $id=(int)$db->lastInsertId();
        }
        $accounts[$email]=['id'=>$id,'password'=>$password];
    }
    $customerEmail='client.demo@estate.local';
    $customer=one_row('SELECT id FROM users WHERE email=?',[$customerEmail]);
    if(!$customer){
        $customerPass=bin2hex(random_bytes(7));
        run_sql("INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,'client')",['Демо Клиент',$customerEmail,'',password_hash($customerPass,PASSWORD_DEFAULT)]);
        $accounts[$customerEmail]=['id'=>(int)$db->lastInsertId(),'password'=>$customerPass];
    }
    $maria=$accounts['maria.demo@estate.local']['id'];$georgi=$accounts['georgi.demo@estate.local']['id'];
    $properties=[
        ['SZ-0101','Светъл двустаен апартамент в Центъра','rent','apartment','Стара Загора','Център','ул. Примерна 1',73,2,1,4,580,'Южно изложение, просторна дневна и тераса.','Иван Георгиев','0888111111',$maria,'active'],
        ['SZ-0102','Компактен двустаен до парк Аязмото','rent','apartment','Стара Загора','Аязмото','ул. Примерна 2',39,2,1,4,340,'Уютно жилище в близост до парк и стадион.','Петър Петров','0888222222',$maria,'active'],
        ['SZ-0103','Тристаен апартамент с две спални','rent','apartment','Стара Загора','Славейков','ул. Примерна 3',86,3,2,5,640,'Просторно жилище с удобни комуникации.','Силвия Иванова','0888333333',$georgi,'active'],
        ['SZ-0104','Семейна къща с двор','sale','house','Стара Загора','Зора','ул. Примерна 4',140,4,3,1,189000,'Самостоятелна къща с двор.','Тодор Тодоров','0888444444',$georgi,'active'],
        ['SZ-0105','Парцел за жилищно строителство','sale','land','Стара Загора','Железник','ул. Примерна 5',680,0,0,0,68000,'Равен парцел с удобен достъп.','Ангел Ангелов','0888555555',$maria,'active'],
        ['SZ-0106','Офис на комуникативна локация','rent','office','Стара Загора','Център','ул. Примерна 6',68,3,0,2,700,'Светъл офис близо до административни учреждения.','Радослав Маринов','0888666666',$georgi,'reserved'],
        ['SZ-0107','Продаден двустаен в Казанлък','sale','apartment','Казанлък','Център','ул. Примерна 7',62,2,1,3,82500,'Пример за приключена сделка.','Нина Николова','0888777777',$maria,'sold'],
        ['SZ-0108','Отдаден под наем апартамент','rent','apartment','Стара Загора','Три чучура','ул. Примерна 8',51,2,1,2,420,'Пример за приключен наем.','Борис Колев','0888888888',$georgi,'rented']
    ];
    $pids=[];
    foreach($properties as $p){run_sql('INSERT INTO properties(ref_code,title,deal_type,type,city,neighborhood,address,area,rooms,bedrooms,floor_no,price,description,owner_name,owner_phone,broker_id,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',$p);$pids[]=(int)$db->lastInsertId();}
    $clients=[
        ['Александър Тодоров','0899000001','alex.demo@example.test','tenant','Търси двустаен близо до центъра.',$maria],
        ['Николета Пенева','0899000002','nik.demo@example.test','buyer','Интересува се от къща.',$georgi],
        ['Станислав Костов','0899000003','stan.demo@example.test','buyer','Парцели и инвестиционни имоти.',$maria],
        ['Виктория Илиева','0899000004','viki.demo@example.test','tenant','Търси тристаен.',$georgi],
        ['Пламен Христов','0899000005','plamen.demo@example.test','buyer','Купувач от демонстрационната продажба.',$maria],
        ['Даниела Стоянова','0899000006','dani.demo@example.test','tenant','Наемател от приключен наем.',$georgi]
    ];
    $cids=[];foreach($clients as $c){run_sql('INSERT INTO clients(name,phone,email,type,notes,broker_id) VALUES(?,?,?,?,?,?)',$c);$cids[]=(int)$db->lastInsertId();}
    $req=[
        [$cids[0],'rent','apartment','Стара Загора',null,null,600,30,2,'Близо до центъра'],
        [$cids[1],'sale','house','Стара Загора',null,null,220000,100,4,'С двор'],
        [$cids[2],'sale','land','Стара Загора',null,null,80000,400,null,'Инвестиция'],
        [$cids[3],'rent','apartment','Стара Загора',null,null,700,70,3,'Две спални']
    ];
    foreach($req as $r)run_sql('INSERT INTO requirements(client_id,deal_type,type,city,neighborhood,min_price,max_price,min_area,min_rooms,notes) VALUES(?,?,?,?,?,?,?,?,?,?)',$r);
    run_sql("INSERT INTO interests(client_id,property_id,broker_id,status,notes) VALUES(?,?,?,'interested','Интерес към жилището')",[$cids[0],$pids[0],$maria]);
    run_sql("INSERT INTO interests(client_id,property_id,broker_id,status,notes) VALUES(?,?,?,'suggested','Изпратена оферта')",[$cids[1],$pids[3],$georgi]);
    $start=(new DateTimeImmutable('tomorrow'))->setTime(11,0)->format('Y-m-d H:i:s');
    $start2=(new DateTimeImmutable('+2 days'))->setTime(16,0)->format('Y-m-d H:i:s');
    run_sql('INSERT INTO viewings(property_id,client_id,broker_id,starts_at,duration_min,note) VALUES(?,?,?,?,?,?)',[$pids[0],$cids[0],$maria,$start,60,'Среща пред входа']);
    run_sql('INSERT INTO viewings(property_id,client_id,broker_id,starts_at,duration_min,note) VALUES(?,?,?,?,?,?)',[$pids[3],$cids[1],$georgi,$start2,45,'Да се потвърди със собственика']);
    $past=(new DateTimeImmutable('-15 days'))->format('Y-m-d');
    run_sql("INSERT INTO deals(property_id,client_id,broker_id,type,amount,commission_percent,commission_amount,deal_date,status,note) VALUES(?, ?, ?, 'sale', ?, ?, ?, ?, 'completed', 'Примерна продажба')",[$pids[6],$cids[4],$maria,82500,3,2475,$past]);
    run_sql("INSERT INTO deals(property_id,client_id,broker_id,type,amount,commission_percent,commission_amount,deal_date,status,note) VALUES(?, ?, ?, 'rent', ?, ?, ?, ?, 'completed', 'Примерен наем')",[$pids[7],$cids[5],$georgi,420,50,210,$past]);
    run_sql('INSERT INTO expenses(title,category,amount,expense_date,creator_id) VALUES(?,?,?,?,?)',['Реклама на имоти','advertising',120,date('Y-m-d'),$admin['id']]);
    if(isset($accounts[$customerEmail])){
        run_sql('INSERT IGNORE INTO favorites(user_id,property_id) VALUES(?,?)',[$accounts[$customerEmail]['id'],$pids[0]]);
    }
    $db->commit();
    echo "Демонстрационните данни са добавени успешно.\n\n";
    foreach($accounts as $email=>$data)echo "$email | password: {$data['password']}\n";
    echo "\nВАЖНО: Паролите са само за локална учебна демонстрация. Запишете ги сега.\n";
}catch(Throwable $e){if(isset($db)&&$db->inTransaction())$db->rollBack();fwrite(STDERR,"Грешка: ".$e->getMessage()."\n");exit(1);}
