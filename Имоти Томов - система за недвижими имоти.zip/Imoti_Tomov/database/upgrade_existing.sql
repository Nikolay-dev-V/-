-- Use ONLY when upgrading an EXISTING EstateManager database, not for a fresh installation.
-- Before running: BACK UP your database (via phpMyAdmin Export).
USE estate_manager;
-- Convert any former managers to brokers. The administrator remains fully privileged.
-- This temporarily retains 'manager' so pre-existing records can be updated safely.
ALTER TABLE users MODIFY role ENUM('admin','manager','broker','client') NOT NULL DEFAULT 'broker';
UPDATE users SET role='broker' WHERE role='manager';
ALTER TABLE users MODIFY role ENUM('admin','broker','client') NOT NULL DEFAULT 'client';
CREATE TABLE IF NOT EXISTS favorites (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 property_id INT UNSIGNED NOT NULL,
 saved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_favorite_user_property(user_id, property_id),
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
 INDEX idx_favorite_property(property_id)
) ENGINE=InnoDB;
