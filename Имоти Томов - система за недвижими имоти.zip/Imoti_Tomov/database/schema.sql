-- Имоти Томов / Вариант 13 -- MySQL 8 / MariaDB 10.5+
-- Database creation (run this entire file once in phpMyAdmin / Import)
CREATE DATABASE IF NOT EXISTS estate_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE estate_manager;

CREATE TABLE IF NOT EXISTS users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(32) DEFAULT NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','broker','client') NOT NULL DEFAULT 'client',
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS properties (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ref_code VARCHAR(32) NOT NULL UNIQUE,
 title VARCHAR(190) NOT NULL,
 deal_type ENUM('sale','rent') NOT NULL,
 type ENUM('apartment','house','land','office','shop','garage','other') NOT NULL,
 city VARCHAR(90) NOT NULL,
 neighborhood VARCHAR(100) DEFAULT NULL,
 address VARCHAR(255) NOT NULL,
 area DECIMAL(11,2) NOT NULL,
 rooms TINYINT UNSIGNED DEFAULT NULL,
 bedrooms TINYINT UNSIGNED DEFAULT NULL,
 floor_no SMALLINT DEFAULT NULL,
 price DECIMAL(13,2) NOT NULL,
 description TEXT,
 owner_name VARCHAR(150) NOT NULL,
 owner_phone VARCHAR(32) NOT NULL,
 broker_id INT UNSIGNED NOT NULL,
 status ENUM('active','reserved','sold','rented','archived') NOT NULL DEFAULT 'active',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (broker_id) REFERENCES users(id) ON DELETE RESTRICT,
 INDEX idx_property_filters (status, deal_type, type, city, price),
 INDEX idx_property_area (area),
 INDEX idx_property_broker (broker_id),
 INDEX idx_property_location (city,neighborhood)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS clients (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 phone VARCHAR(32) NOT NULL,
 email VARCHAR(190) DEFAULT NULL,
 type ENUM('buyer','tenant','seller','landlord','other') NOT NULL DEFAULT 'buyer',
 notes TEXT,
 broker_id INT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (broker_id) REFERENCES users(id) ON DELETE RESTRICT,
 INDEX idx_client_broker (broker_id), INDEX idx_client_name (name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS requirements (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 client_id INT UNSIGNED NOT NULL,
 deal_type ENUM('sale','rent') NOT NULL,
 type ENUM('apartment','house','land','office','shop','garage','other') DEFAULT NULL,
 city VARCHAR(90) DEFAULT NULL,
 neighborhood VARCHAR(100) DEFAULT NULL,
 min_price DECIMAL(13,2) DEFAULT NULL,
 max_price DECIMAL(13,2) DEFAULT NULL,
 min_area DECIMAL(11,2) DEFAULT NULL,
 min_rooms TINYINT UNSIGNED DEFAULT NULL,
 notes TEXT,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
 INDEX idx_req_client (client_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS interests (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 client_id INT UNSIGNED NOT NULL,
 property_id INT UNSIGNED NOT NULL,
 broker_id INT UNSIGNED NOT NULL,
 status ENUM('suggested','interested','viewed','declined') NOT NULL DEFAULT 'suggested',
 notes TEXT,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_client_property (client_id,property_id),
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
 FOREIGN KEY (broker_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS viewings (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 property_id INT UNSIGNED NOT NULL,
 client_id INT UNSIGNED NOT NULL,
 broker_id INT UNSIGNED NOT NULL,
 starts_at DATETIME NOT NULL,
 duration_min SMALLINT UNSIGNED NOT NULL DEFAULT 60,
 status ENUM('planned','completed','cancelled','no_show') NOT NULL DEFAULT 'planned',
 note TEXT,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE RESTRICT,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE RESTRICT,
 FOREIGN KEY (broker_id) REFERENCES users(id) ON DELETE RESTRICT,
 INDEX idx_viewing_conflict (broker_id,status,starts_at),
 INDEX idx_viewing_property (property_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS deals (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 property_id INT UNSIGNED NOT NULL,
 client_id INT UNSIGNED NOT NULL,
 broker_id INT UNSIGNED NOT NULL,
 type ENUM('sale','rent') NOT NULL,
 amount DECIMAL(13,2) NOT NULL,
 commission_percent DECIMAL(5,2) NOT NULL,
 commission_amount DECIMAL(13,2) NOT NULL,
 deal_date DATE NOT NULL,
 status ENUM('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
 note TEXT,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE RESTRICT,
 FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE RESTRICT,
 FOREIGN KEY (broker_id) REFERENCES users(id) ON DELETE RESTRICT,
 INDEX idx_deal_month (status,deal_date), INDEX idx_deal_broker (broker_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS expenses (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(190) NOT NULL,
 category ENUM('advertising','office','transport','maintenance','other') NOT NULL DEFAULT 'other',
 amount DECIMAL(13,2) NOT NULL,
 expense_date DATE NOT NULL,
 creator_id INT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE RESTRICT,
 INDEX idx_expense_month (expense_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS documents (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(190) NOT NULL,
 property_id INT UNSIGNED DEFAULT NULL,
 deal_id INT UNSIGNED DEFAULT NULL,
 stored_filename VARCHAR(80) NOT NULL,
 original_filename VARCHAR(255) NOT NULL,
 mime_type VARCHAR(60) NOT NULL,
 byte_size INT UNSIGNED NOT NULL,
 creator_id INT UNSIGNED NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL,
 FOREIGN KEY (deal_id) REFERENCES deals(id) ON DELETE SET NULL,
 FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE RESTRICT,
 INDEX idx_doc_property (property_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED DEFAULT NULL,
 action VARCHAR(60) NOT NULL,
 entity VARCHAR(60) NOT NULL,
 entity_id INT UNSIGNED DEFAULT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_audit_time (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS property_photos (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 property_id INT UNSIGNED NOT NULL,
 stored_filename VARCHAR(80) NOT NULL,
 mime_type VARCHAR(60) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
 INDEX idx_photo_property (property_id)
) ENGINE=InnoDB;


-- Registered website visitors; independent of CRM contacts in `clients`.
CREATE TABLE IF NOT EXISTS favorites (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 property_id INT UNSIGNED NOT NULL,
 saved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_favorite_user_property(user_id, property_id),
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
 INDEX idx_favorite_property(property_id)
) ENGINE=InnoDB;
